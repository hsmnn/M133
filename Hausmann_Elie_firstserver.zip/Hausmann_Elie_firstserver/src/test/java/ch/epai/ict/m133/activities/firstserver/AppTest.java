package ch.epai.ict.m133.activities.firstserver;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Représente les tests unitaires de la classe App.
 */
public class AppTest {

    /**
     * Test trivial (toujours vrai)
     */
    @Test
    public void shouldAnswerWithTrue() {
        assertTrue(true);
    }
}
