package ch.epai.ict.m133.activities.firstserver;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.function.Consumer;

import io.javalin.Javalin;
import io.javalin.core.JavalinConfig;
import io.javalin.http.HandlerType;
import io.javalin.http.staticfiles.Location;

/**
 * Une classe pour créer et configure un objet de type Javalin qui représente un
 * serveur HTTP.
 */
public class ServerBuilder implements Consumer<JavalinConfig> {

    private static final String STATIC_DIR = "public";

    /**
     * Crée, configure et renvoie une instance de la classe Javalin.
     *
     * @return une instance de la classe Javalin
     */
    public Javalin build() {
        Javalin app = Javalin.create(this);
        this.addRoutes(app);
        return app;
    }

    /**
     * Configure le serveur HTTP à l'aide des méthodes de l'instance de
     * JavalinConfig passée en paramètre.
     *
     * @param config une instance du type JavalinConfig
     */
    @Override
    public void accept(JavalinConfig config) {

        // Ajoute un gestionnaire de requête pour les ressources statiques, si un
        // répertoire nommé "public" existe dans le répertoire courant.
        Path staticDirPath = Paths.get(".", STATIC_DIR);
        if (Files.exists(staticDirPath)) {
            // Gestion des ressources statiques. Si le chemin de l'URI correspond au chemin
            // d'un fichier dans le répertoire /public, renvoie le contenu du fichier.
            config.addStaticFiles(staticDirPath.toString(), Location.EXTERNAL);
        }

        config.showJavalinBanner = false;
    }

    /**
     * Pour chaque ressource gérée par l'application, associe l'URI de la ressource
     * et une méthode HTTP (GET, POST, etc.) à un gestionnaire de requête (request
     * handler).
     *
     * Il est d'usage d'appeler une telle association «route» ou «endpoint». Le
     * terme «route» met l'accent sur le fait que l'URI qui permet de trouver le
     * gestionnaire alors que le terme «endpoint» met l'accent sur le fait que le
     * gestionnaire est le point d'arrivée de la requête.
     *
     * @param app l'instance de Javalin à laquelle les gestionnaires de requêtes
     *            doivent être ajoutés.
     */
    private void addRoutes(Javalin app) {

        // Ajoute l'instance de HomeHandler associée à la méthode GET et à l'URI "/".
        app.addHandler(HandlerType.GET, "/", HomeHandler.INSTANCE);
        app.addHandler(HandlerType.GET, "/guestbook", GuestBookHandler.INSTANCE);
        app.addHandler(HandlerType.POST, "/guestbookpost", GuestBookPost.INSTANCE);

    }
}
