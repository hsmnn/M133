package ch.epai.ict.m133.activities.firstserver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import io.javalin.http.Context;
import io.javalin.http.Handler;



/**
 * Gestionnaire de requête pour la ressource guestbook de l'application web.
 */
public final class GuestBookPost implements Handler {

    /**
     * Instance unique de la classe (pattern singleton).
     */
    public static final Handler INSTANCE = new GuestBookPost();

    /**
     * Constructeur privé
     */
    private GuestBookPost() {
    }

    /**
     * La méthode handle effectue le traitement des requêtes
     */
    @Override
    public void handle(Context ctx) throws Exception {

        // Localise la base de données guestbook
        String mySqlUrl = "jdbc:mariadb://localhost/guestbook";
        // Créé une connexion avec la base de données
        Connection connection = DriverManager.getConnection(mySqlUrl, "root", "epai123");

        try {
            // Définit la requête SQL
            String pseudo = ctx.formParam("nickname");
            String message = ctx.formParam("message");
            String query = "INSERT INTO message (pseudo, message) VALUES ('" + pseudo + "', '" + message + "')";

            // Crée une instruction sql et execute la requête.
            Statement statement = connection.createStatement();
            if (pseudo != null || message != null) {
                statement.executeQuery(query);
            }

        } finally {
            // Met fin à la connexion avec la base de données
            connection.close();
        }

        ctx.redirect("/guestbook");

    }
}