package ch.epai.ict.m133.activities.firstserver;

import freemarker.template.Configuration;
import io.javalin.Javalin;
import io.javalin.plugin.rendering.template.JavalinFreemarker;

/**
 * Représente l'application.
 *
 * Note : La manière dont Javalin est utilisé dans cette exemple est assez
 * différente ce que l'on peut trouver dans la documentation de ce framework. La
 * raison est que le public auquel est destiné ce code n'est familier ni avac la
 * notion d'expression lambda ni avec celle de fermeture (closure). Nous avons
 * donc choisi de réaliser cet exemple en n'utilisant que les notions déjà
 * étudiées.
 */
public class App {

    private static final int DEFAULT_PORT = 8080;

    /**
     * Point d'entrée du programme.
     *
     * @param args paramètres de la ligne de commande
     */
    public static void main(String[] args) {

        // Configure le moteur de template FreeMarker (https://freemarker.apache.org/)
        // pour qu'il cherche les templates dans le répertoire "templates" des
        // ressources qui se trouve dans le jar. Dans le code source, les templates
        // doivent se trouver dans le répertoire src/main/resources/templates/.
        Configuration configuration = new Configuration(Configuration.VERSION_2_3_29);
        configuration.setClassForTemplateLoading(App.class, "/templates");
        JavalinFreemarker.configure(configuration);

        // Construit un nouveau server HTTP.
        ServerBuilder builder = new ServerBuilder();
        Javalin app = builder.build();

        // Démarre le server HTTP, c'est-à-dire commence à écouter le port 8080 et
        // accepte les demande de connexion.
        app.start(DEFAULT_PORT);
    }
}
