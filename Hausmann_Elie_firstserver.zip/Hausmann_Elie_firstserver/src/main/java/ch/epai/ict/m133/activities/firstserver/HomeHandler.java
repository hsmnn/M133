package ch.epai.ict.m133.activities.firstserver;

import java.util.HashMap;
import java.util.Map;

import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Gestionnaire de requête pour la ressource Home de l'application web.
 */
public final class HomeHandler implements Handler {

    /**
     * Instance unique de la classe (pattern singleton).
     */
    public static final Handler INSTANCE = new HomeHandler();

    /**
     * Constructeur privé.
     *
     * Puisque la classe n'a aucune variable membre, les instances n'ont pas d'état.
     * Il n'y a donc aucune raison d'avoir plusieurs instance de cette classe et on
     * peut en faire un singleton. Un constructeur privé assure que la classe ne
     * peut être instanciée qu'à l'intérieur de la classe elle-même. Dans notre cas,
     * l'instance est crée lorsque le membre statique INSTANCE est initialisé.
     */
    private HomeHandler() {
    }

    /**
     * La méthode handle effectue le traitement des requêtes. Le traitement consiste
     * généralement à produire un réponse HTTP adéquate. Lorsque la méthode de la
     * requête est un GET il s'agit en général de produire une représentation de la
     * ressource.
     *
     * @param ctx une instance de la classe Context qui permet d'accéder aux
     *            informations de la requête HTTP et qui sert de builder pour la
     *            réponse HTTP.
     */
    @Override
    public void handle(Context ctx) throws Exception {

        // Crée un tableau associatif (Map) et spécifie une valeur pour chaque variable
        // du template.
        Map<String, Object> data = new HashMap<>();
        data.put("title", "Premier serveur"); // associe la chaîne "Premier serveur" à la variable nommée title.
        data.put("name", "world"); // associe la chaine "world" à la variable nommée name.

        // Combine le template et les données, puis envoie la réponse au client.
        // Attention : La méthode render modifie la valeur de l'en-tête "Content-Type"
        // et lui donne la valeur "text/html". Cette méthode ne peut donc être utilisée
        // que pour envoyer du HTML.
        ctx.render("/home.ftl", data);
    }
}
