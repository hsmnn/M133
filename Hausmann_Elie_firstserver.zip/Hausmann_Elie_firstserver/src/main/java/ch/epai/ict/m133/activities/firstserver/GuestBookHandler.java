package ch.epai.ict.m133.activities.firstserver;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.javalin.http.Context;
import io.javalin.http.Handler;



/**
 * Gestionnaire de requête pour la ressource guestbook de l'application web.
 */
public final class GuestBookHandler implements Handler {

    /**
     * Instance unique de la classe (pattern singleton).
     */
    public static final Handler INSTANCE = new GuestBookHandler();

    /**
     * Constructeur privé
     */
    private GuestBookHandler() {
    }

    /**
     * La méthode handle effectue le traitement des requêtes
     */
    @Override
    public void handle(Context ctx) throws Exception {

        // Localise la base de données guestbook
        String mySqlUrl = "jdbc:mariadb://localhost/guestbook";
        // Créé une connexion avec la base de données
        Connection connection = DriverManager.getConnection(mySqlUrl, "root", "epai123");
        // Création d'une Map pour stocker les données des messages
        Map<String, Object> data = new HashMap<>();
        List<String> dates = new ArrayList<String>();
        List<String> nicknames = new ArrayList<String>();
        List<String> messages = new ArrayList<String>();
        // Ajoute le titre de la page à la Map
        data.put("title", "Guestbook");

        try {
            // Définit la requête SQL
            String query = "SELECT * FROM message";

            // Crée une instruction sql et execute la requête.
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);

            // Parcourt l'ensemble de résultats (result set)
            int i = 0;
            while (rs.next()) {
                int messageId = rs.getInt("messageID");
                Date messageDate = rs.getDate("messageDate");
                String pseudo = rs.getString("pseudo");
                String message = rs.getString("message");

                // Stock les valeurs dans la Map
                dates.add(messageDate.toString());
                nicknames.add(pseudo);
                messages.add(message);
                i += 1;
            }
        } finally {
            // Met fin à la connexion avec la base de données
            connection.close();
        }
        
        data.put("messages", messages);
        data.put("dates", dates);
        data.put("nicknames", nicknames);
        // Affiche le template /guestbook.ftl et lui donne la Map datas comme paramètre
        ctx.render("/guestbook.ftl", data);

    }
}