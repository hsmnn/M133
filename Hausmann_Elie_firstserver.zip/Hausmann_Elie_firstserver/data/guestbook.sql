CREATE DATABASE guestbook DEFAULT CHARSET UTF8;
use guestbook;

CREATE TABLE message (
    messageID    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    messageDate  TIMESTAMP DEFAULT NOW(),
    pseudo       VARCHAR(50),
    message      VARCHAR(512),
PRIMARY KEY (messageID)
);