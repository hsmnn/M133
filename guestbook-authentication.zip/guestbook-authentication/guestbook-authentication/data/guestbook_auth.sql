CREATE DATABASE guestbook_auth DEFAULT CHARSET UTF8;
use guestbook_auth;

CREATE TABLE message (
    message_id    BIGINT UNSIGNED NOT NULL,
    message_date  TIMESTAMP DEFAULT NOW(),
    user_name     VARCHAR(50),
    message_body  VARCHAR(512),
PRIMARY KEY (message_id)
);

CREATE TABLE user (
    user_id       BIGINT UNSIGNED NOT NULL,
    user_name     VARCHAR(50),
    email         VARCHAR(50),
    display_name  VARCHAR(50),
    password_hash VARCHAR(255),
    role          VARCHAR(255),
PRIMARY KEY (user_id)
);

CREATE TABLE entity_counter (
    entity_id     INT UNSIGNED NOT NULL,
    counter_value BIGINT UNSIGNED NOT NULL,
    entity_name   VARCHAR(50),
PRIMARY KEY (entity_id)
);

INSERT INTO entity_counter (entity_id, counter_value, entity_name) VALUES (1, 1000, "message");
INSERT INTO entity_counter (entity_id, counter_value, entity_name) VALUES (2, 1000, "user");
