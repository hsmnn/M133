package ch.epai.ict.m133.activities.guestbook;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import ch.epai.ict.m133.activities.guestbook.data.sql.SqlConnectionManager;
import ch.epai.ict.m133.activities.guestbook.data.sql.SqlIdGenerator;
import ch.epai.ict.m133.activities.guestbook.data.sql.SqlMessageDataMapper;
import ch.epai.ict.m133.activities.guestbook.data.sql.SqlUserDataMapper;
import ch.epai.ict.m133.activities.guestbook.domain.IdGenerator;
import ch.epai.ict.m133.activities.guestbook.domain.Message;
import ch.epai.ict.m133.activities.guestbook.domain.MessageRepository;
import ch.epai.ict.m133.activities.guestbook.domain.User;
import ch.epai.ict.m133.activities.guestbook.domain.UserDirectory;
import ch.epai.ict.m133.activities.guestbook.web.handlers.GuestbookPageHandler;
import ch.epai.ict.m133.activities.guestbook.web.handlers.HomePageHandler;
import ch.epai.ict.m133.activities.guestbook.web.handlers.LoginPageHandler;
import ch.epai.ict.m133.activities.guestbook.web.handlers.NewMessageActionHandler;
import ch.epai.ict.m133.activities.guestbook.web.handlers.SignUpActionHandler;
import ch.epai.ict.m133.activities.guestbook.web.handlers.SignupPageHandler;
import ch.epai.ict.m133.activities.guestbook.web.handlers.UserIdActionHandler;
import ch.epai.ict.m133.activities.guestbook.web.handlers.UserIdPageHandler;
import ch.epai.ict.m133.activities.guestbook.web.handlers.UsersPageHandler;
import ch.epai.ict.m133.activities.guestbook.web.security.Authenticator;
import ch.epai.ict.m133.activities.guestbook.web.security.FormAuthenticator;
import freemarker.template.Configuration;
import io.javalin.Javalin;
import io.javalin.http.HandlerType;
import io.javalin.http.staticfiles.Location;
import io.javalin.plugin.rendering.template.JavalinFreemarker;

/**
 * Cette classe permet de configurer les objets métiers (domain objects) et de
 * créer et configurer un objet de type Javalin qui représente un serveur HTTP.
 */
public class ServerBuilder {

    private static final String STATIC_DIR = "public";

    private static final String LOGIN_URL = "/login";
    private static final String SIGNUP_ACTION_URL = "/sign-up";
    private static final String SIGNIN_ACTION_URL = "/sign-in";
    private static final String SIGNOUT_ACTION_URL = "/sign-out";
    private static final String USERNAME_PARAM = "username";
    private static final String PASSWORD_PARAM = "password";

    private final AppConfig config;

    /**
     * Crée un builder pour construire une serveur web avec Jetty.
     *
     * @param appConfig la configuration de l'application
     * @return
     */
    public static ServerBuilder create(AppConfig config) {
        return new ServerBuilder(config);
    }

    /**
     * Constructeur.
     *
     * @param config données de configuration.
     */
    private ServerBuilder(AppConfig config) {
        this.config = config;
    }

    /**
     * Crée, configure et renvoie une instance de la classe Javalin.
     *
     * Configure les objects métiers (domain objects) et les enregistres dans le
     * localisateur de service qui est un singleton. Bien que l'usage d'un
     * localisateur de service soit considéré par certains comme un anti-pattern, ce
     * patron de conception est bien documenté (voir notamment <a
     * href=https://martinfowler.com/articles/injection.html#UsingAServiceLocator">Martin
     * Fowler</a>) c'est une manière simple de respecter le principe d'inversion de
     * dépendance.
     *
     * @return une instance de la classe Javalin
     */
    public Javalin build() {

        // Instancie une application javaline. Le paramètre de la méthode create
        // est un peu particulier. Il s'agit d'une fonction lambda
        // (https://www.jmdoudoux.fr/java/dej/chap-lambdas.htm) C'est-à-dire que la
        // valeur que l'on passe à la méthode est une fonction que la méthode
        // peut appeler.
        final Javalin app = Javalin.create(javalinConfig -> {
            final Path staticDirPath = Paths.get(".", STATIC_DIR);
            if (Files.exists(staticDirPath)) {
                javalinConfig.addStaticFiles(staticDirPath.toString(), Location.EXTERNAL);
            }
            javalinConfig.showJavalinBanner = false;
        });

        // Configure le moteur de template FreeMarker (https://freemarker.apache.org/)
        // pour qu'il cherche les templates dans le répertoire "templates" des
        // ressources qui se trouve dans le jar. Dans le code source, les templates
        // doivent se trouver dans le répertoire src/main/resources/templates/.
        Configuration configuration = new Configuration(Configuration.VERSION_2_3_29);
        configuration.setClassForTemplateLoading(App.class, "/templates");
        JavalinFreemarker.configure(configuration);

        // Instancie les dépôts (repositories) de messages et d'utilisateurs.
        SqlConnectionManager connectionManager = new SqlConnectionManager(
                this.config.getDbUrl(),
                this.config.getDbUser(),
                this.config.getDbPassword());

        UserDirectory userDir = new SqlUserDataMapper(connectionManager);
        MessageRepository messageDataMapper = new SqlMessageDataMapper(connectionManager);

        // Configure les générateur d'identifiant
        IdGenerator.register(Message.class, new SqlIdGenerator(connectionManager, "message"));
        IdGenerator.register(User.class, new SqlIdGenerator(connectionManager, "user"));

        // Initialise la partie web de l'application.
        FormAuthenticator formAuth = new FormAuthenticator(
                app, userDir,
                LOGIN_URL, SIGNIN_ACTION_URL, SIGNOUT_ACTION_URL,
                USERNAME_PARAM, PASSWORD_PARAM);
        Authenticator.register(formAuth);

        // Ajoute les routes (gestionnaire de requête) de l'application
        this.addRoutes(app, userDir, messageDataMapper);

        return app;
    }

    /**
     * Pour chaque ressource gérée par l'application, associe l'URI de la ressource
     * et une méthode HTTP (GET, POST, etc.) à un gestionnaire de requête (request
     * handler).
     *
     * Il est d'usage d'appeler une telle association «route» ou «endpoint». Le
     * terme «route» met l'accent sur le fait que l'URI permet de trouver le
     * gestionnaire alors que le terme «endpoint» met l'accent sur le fait que le
     * gestionnaire est le point d'arrivée de la requête.
     *
     * @param app l'instance de Javalin à laquelle les gestionnaires de requêtes
     *            doivent être ajoutés.
     */
    private void addRoutes(Javalin app, UserDirectory userDir, MessageRepository messageRepo) {

        app.addHandler(HandlerType.GET, "/", new HomePageHandler("Premier serveur"));
        app.addHandler(HandlerType.GET, "/guestbook", new GuestbookPageHandler(messageRepo, "/guestbook"));
        app.addHandler(HandlerType.POST, "/guestbook", new NewMessageActionHandler(messageRepo, "/guestbook"));

        app.addHandler(HandlerType.GET, LOGIN_URL, new LoginPageHandler(SIGNIN_ACTION_URL));
        app.addHandler(HandlerType.POST, SIGNUP_ACTION_URL, new SignUpActionHandler(LOGIN_URL, userDir));

        // AJOUTER DES HANDLER ICIs
        app.addHandler(HandlerType.GET, "/signup", new SignupPageHandler(SIGNUP_ACTION_URL));
        app.addHandler(HandlerType.GET, "/users", new UsersPageHandler(userDir));
        app.addHandler(HandlerType.GET, "/users/:userid", new UserIdPageHandler(userDir));
        app.addHandler(HandlerType.GET, "/delete/:userid", new UserIdActionHandler(userDir));
    }
}
