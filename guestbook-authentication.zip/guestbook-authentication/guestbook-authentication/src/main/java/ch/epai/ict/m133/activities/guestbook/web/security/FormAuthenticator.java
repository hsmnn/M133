package ch.epai.ict.m133.activities.guestbook.web.security;

import ch.epai.ict.m133.activities.guestbook.domain.User;
import ch.epai.ict.m133.activities.guestbook.domain.UserDirectory;
import ch.epai.ict.m133.activities.guestbook.web.utils.ContextUtils;
import ch.epai.ict.m133.activities.guestbook.web.utils.LoginPageErrorUtils;
import ch.epai.ict.m133.activities.guestbook.web.utils.SessionUtils;
import io.javalin.Javalin;
import io.javalin.http.Context;
import io.javalin.http.HandlerType;

/**
 * Implémente un mécanisme d'authentification basé sur un formulaire HTML.
 */
public final class FormAuthenticator extends Authenticator {

    private static final String USER_ATTRIBUTE = "FORM_AUTH_USER";
    private static final String INVALID_CREDENTIALS_ATTRIBUTE = "FORM_AUTH_INVALID_CREDENTIALS";
    private static final String RETURN_URL_ATTRIBUTE = "FORM_AUTH_RETURN_URL";

    private UserDirectory userDir;
    private String loginUrl;
    private String userNameParameter;
    private String passwordParameter;

    public FormAuthenticator(Javalin app) {
        super(app);
    }

    /**
     * Constructeur.
     *
     * @param app               l'application Javalin
     * @param userDir           un répertoire d'utilisateur
     * @param loginUrl          l'URL du formulaire de connexion
     * @param signInActionUrl   l'URL d'action du formulaire de connexion
     * @param signOutActionUrl  l'URL d'action pour la déconnexion
     * @param userNameParameter le nom du paramètre pour le nom d'utilisateur
     * @param passwordParameter le nom du paramètre pour le mot de passe
     */
    public FormAuthenticator(Javalin app, UserDirectory userDir, String loginUrl, String signInActionUrl,
            String signOutActionUrl, String userNameParameter, String passwordParameter) {

        super(app);

        this.userDir = userDir;
        this.loginUrl = loginUrl;
        this.userNameParameter = userNameParameter;
        this.passwordParameter = passwordParameter;

        // Ces trois handler sont réalisés à l'aide d'expressions lambda plutôt qu'avec
        // des instances de classes qui implémente le type Handler. Une expression
        // lambda est équivalente à un objet qui implémente une interface avec une seule
        // méthode (parfois appelée interface fonctionnelle). Ici, on utilise les
        // méthodes handleSignIn et handleSignOut plutôt que de réaliser deux classe
        // imbriquées SignInHandler et SignOutHandler.
        app.addHandler(HandlerType.POST, signInActionUrl, this::handleSignIn);
        app.addHandler(HandlerType.GET, signOutActionUrl, this::handleSignOut);
        app.addHandler(HandlerType.POST, signOutActionUrl, this::handleSignOut);
    }

    @Override
    protected void doLogin(Context ctx) {
        if (ContextUtils.isAuthenticated(ctx)) {
            return;
        }

        String returnUrl = SessionUtils.getAttribute(ctx, RETURN_URL_ATTRIBUTE);
        if (returnUrl == null) {
            returnUrl = "";
        }
        if (returnUrl.isEmpty()) {
            returnUrl = ctx.fullUrl();
            SessionUtils.setAttribute(ctx, RETURN_URL_ATTRIBUTE, returnUrl);
        }

        ctx.redirect(this.loginUrl);
    }

    @Override
    protected void doAuthenticate(Context ctx) {
        if (ContextUtils.isAuthenticated(ctx)) {
            return;
        }

        User user = SessionUtils.getAttribute(ctx, USER_ATTRIBUTE);
        if (user != null) {
            ContextUtils.setUser(ctx, user);
        } else {
            ContextUtils.setUser(ctx, null);
        }
    }

    /**
     * Gestionnaire de requête pour l'action du formulaire de connexion (sign-in).
     *
     * @param ctx le contexte
     */
    private void handleSignIn(Context ctx) {
        SessionUtils.setAttribute(ctx, INVALID_CREDENTIALS_ATTRIBUTE, null);

        String userName = ctx.formParam(this.userNameParameter);
        String password = ctx.formParam(this.passwordParameter);

        if (this.userDir.validate(userName, password)) {

            User user = this.userDir.getUserByUserName(userName);
            SessionUtils.setAttribute(ctx, USER_ATTRIBUTE, user);

            String location = SessionUtils.getAndClearAttribute(ctx, RETURN_URL_ATTRIBUTE, "/");
            if (location.isEmpty()) {
                location = "/";
            }

            // Change l'identifiant de session par mesure de sécurité.
            ctx.req.changeSessionId();

            ctx.redirect(location);

        } else {
            LoginPageErrorUtils.setSignInError(ctx, LoginPageErrorUtils.INVALID_CREDENTIALS);
            ctx.redirect(this.loginUrl);
        }
    }

    /**
     * Gestionnaire de requête pour la déconnexion (sign-out).
     *
     * @param ctx le contexte
     */
    private void handleSignOut(Context ctx) {
        ContextUtils.setUser(ctx, null);
        SessionUtils.clearAttribute(ctx, USER_ATTRIBUTE);

        // change l'identifiant de session par mesure de sécurité.
        ctx.req.changeSessionId();

        ctx.redirect(this.loginUrl);
    }

}
