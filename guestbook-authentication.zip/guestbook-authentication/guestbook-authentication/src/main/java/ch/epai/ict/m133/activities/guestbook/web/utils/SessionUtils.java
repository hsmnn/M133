package ch.epai.ict.m133.activities.guestbook.web.utils;

import io.javalin.http.Context;

public class SessionUtils {

    public static <T> T getAttribute(Context ctx, String key) {
        return getAttribute(ctx, key, null);
    }

    public static <T> T getAttribute(Context ctx, String key, T defaultValue) {
        if (ctx.req.getRequestedSessionId() == null) {
            return defaultValue;
        }
        T value = ctx.sessionAttribute(key);
        if (value == null) {
            return defaultValue;
        }
        return value;
    }

    public static <T> T getAndClearAttribute(Context ctx, String key) {
        return getAttribute(ctx, key, null);
    }

    public static <T> T getAndClearAttribute(Context ctx, String key, T defaultValue) {
        if (ctx.req.getRequestedSessionId() == null) {
            return defaultValue;
        }
        T value = ctx.sessionAttribute(key);
        ctx.sessionAttribute(key, null);
        if (value == null) {
            return defaultValue;
        }
        return value;
    }

    public static void clearAttribute(Context ctx, String key) {
        if (ctx.req.getRequestedSessionId() == null) {
            return;
        }
        ctx.sessionAttribute(key, null);
    }

    public static <T> void setAttribute(Context ctx, String key, T value) {
        ctx.sessionAttribute(key, value);
    }
}
