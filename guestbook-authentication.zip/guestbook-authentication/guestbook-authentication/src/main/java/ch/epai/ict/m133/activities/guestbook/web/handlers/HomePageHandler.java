package ch.epai.ict.m133.activities.guestbook.web.handlers;

import java.util.HashMap;
import java.util.Map;

import ch.epai.ict.m133.activities.guestbook.web.utils.ContextUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Gestionnaire de requête pour la page d'accueil.
 */
public final class HomePageHandler implements Handler {

    private final String title;

    /**
     * Constructeur
     * 
     * L'argument titre n'est là que pour illustrer la manière d'initialiser un
     * gestionaire de requête avec son constructeur.
     * 
     * @param title le titre du site
     */
    public HomePageHandler(String title) {
        this.title = title;
    }
    
    /**
     * Effectue le traitement des requêtes.
     *
     * @param ctx le contexte de la requête
     */
    @Override
    public void handle(Context ctx) throws Exception {

        Map<String, Object> data = new HashMap<>();
        data.put("title", this.title);
        data.put("name", "world");
        data.put("isAuthenticated", ContextUtils.isAuthenticated(ctx));

        ctx.render("/home.ftl", data);
    }
}
