package ch.epai.ict.m133.activities.guestbook.data.sql;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Représente un gestionnaire de connexions à la base de données.
 *
 * Une meilleures implémentation pourrait utiliser un pool de connexions pour
 * éviter d'avoir à ouvrire une nouvelle connexion à chaque requête.
 */
public final class SqlConnectionManager {

    private String url;
    private String user;
    private String password;

    /**
     * Cosntructeur.
     *
     * @param url      l'url de connexion (dépend du SGBD)
     * @param user     le nom de l'utilisateur du SGBD
     * @param password le mot de passe l'utilisateur du SGBD
     */
    public SqlConnectionManager(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    /**
     * Renvoie une connection à la base de données.
     *
     * @return une connection à la base de données
     */
    public Connection getConnection() {
        try {
            return DriverManager.getConnection(this.url, this.user, this.password);
        } catch (Exception ex) {
            throw new RuntimeException("Can't get database connection!", ex);
        }
    }
}
