package ch.epai.ict.m133.activities.guestbook.web.handlers;

import ch.epai.ict.m133.activities.guestbook.domain.User;
import ch.epai.ict.m133.activities.guestbook.domain.UserBuilder;
import ch.epai.ict.m133.activities.guestbook.domain.UserDirectory;
import ch.epai.ict.m133.activities.guestbook.web.utils.LoginPageErrorUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Gestionnaire de requête pour la méthode POST sur la ressource signup.
 *
 */
public final class SignUpActionHandler implements Handler {

    private final String signUpFormUrl;
    private final UserDirectory userDir;

    /**
     * Constructeur
     *
     * @param signUpFormUrl URL du formulaire d'inscription
     */
    public SignUpActionHandler(String signUpFormUrl, UserDirectory userDir) {
        this.signUpFormUrl = signUpFormUrl;
        this.userDir = userDir;
    }

    /**
     * Effectue le traitement des requêtes.
     *
     * @param ctx le contexte de la requête
     */
    @Override
    public void handle(Context ctx) {

        // Récupères les données du formualaire.
        String userName = ctx.formParam("username");
        String email = ctx.formParam("email");
        String displayName = ctx.formParam("displayname");
        String password = ctx.formParam("password");
        String confirmation = ctx.formParam("confirmation");

        // Vérifie que les données du formulaire sont valides. Si ce n'est pas le cas,
        // stocke une erreur dans les données de session et effectue une demande de
        // redirection vers le formulaire d'inscription.

        if (userName.isEmpty() || email.isEmpty() || displayName.isEmpty() || password.isEmpty()) {
            LoginPageErrorUtils.setSignUpError(ctx, LoginPageErrorUtils.REQUIRED_FIELDS_MISSING);
            ctx.redirect(this.signUpFormUrl);
            return;
        }

        User user = this.userDir.getUserByUserName(userName);
        if (user != null) {
            LoginPageErrorUtils.setSignUpError(ctx, LoginPageErrorUtils.USERNAME_ALREADY_EXISTS);
            ctx.redirect(this.signUpFormUrl);
            return;
        }

        user =  this.userDir.getUserByEmail(email);
        if (user != null) {
            LoginPageErrorUtils.setSignUpError(ctx, LoginPageErrorUtils.EMAIL_ALREADY_EXISTS);
            ctx.redirect(this.signUpFormUrl);
            return;
        }

        if (!password.equals(confirmation)) {
            LoginPageErrorUtils.setSignUpError(ctx, LoginPageErrorUtils.PASSWORD_MISMATCH);
            ctx.redirect(this.signUpFormUrl);
            return;
        }

        // Utilise un builder pour créer un nouvel utilisateur et ajoute ce nouvel
        // utilisateur dans le répertoire (UserDirectory).
        user = UserBuilder.create()
            .setUserName(userName)
            .setEmail(email)
            .setDisplayName(displayName)
            .setRole("user")
            .buildUser();

        this.userDir.addUser(user, password);

        // Stocke une "erreur" dans les données de session pour signaler que
        // l'utilisateur a été correctement ajouté.
        LoginPageErrorUtils.setSignUpError(ctx, LoginPageErrorUtils.USER_SUCCESSFULLY_CREATED);

        // Effectue une demande de redirection vers le formulaire de login.
        ctx.redirect(this.signUpFormUrl);
    }
}
