package ch.epai.ict.m133.activities.guestbook.data.sql;

import ch.epai.ict.m133.activities.guestbook.domain.IdGenerator;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Implémente un générateur d'identifiant en utilisant une table dans une base
 * de données SQL.
 */
public final class SqlIdGenerator extends IdGenerator {

    private static final int NUM_OF_ID = 10;

    private SqlConnectionManager connectionManager;
    private int currentId;
    private int maxId;
    private String tableName;

    /**
     * Constructeur.
     *
     * @param connectionManager un gestionnaire de connexions SQL.
     * @param tableName le nom de l'entité pour laquel les identifiants sont générés.
     */
    public SqlIdGenerator(SqlConnectionManager connectionManager, String tableName) {
        this.connectionManager = connectionManager;
        this.tableName = tableName;
    }

    /**
     * Renvoie le prochain identifiant.
     *
     * La méthode n'accède pas à la base de données à chaque appelle, mais seulement une fois
     * sur dix. Si le serveur est arrêté, les identifiants non utilisés sont perdus.
     */
    @Override
    public synchronized int getNextId() {

        if (this.currentId < this.maxId) {

            this.currentId += 1;

        } else {

            int counterValue = -1;
            try (Connection connection = connectionManager.getConnection();
                    Statement statement = connection.createStatement();) {
                connection.setAutoCommit(false);
                statement.executeUpdate(String.format(
                        "UPDATE entity_counter SET counter_value = counter_value + %d WHERE entity_name = '%s'",
                        NUM_OF_ID, this.tableName));
                ResultSet rs = statement.executeQuery(String
                        .format("SELECT counter_value FROM entity_counter WHERE entity_name = '%s'", this.tableName));
                while (rs.next()) {
                    counterValue = rs.getInt("counter_value");
                }
                connection.commit();

            } catch (Exception ex) {
                throw new RuntimeException("Can't generate message id!", ex);
            }
            this.currentId = counterValue;
            this.maxId = (counterValue + NUM_OF_ID) - 1;
        }

        return this.currentId;
    }

}
