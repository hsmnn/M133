package ch.epai.ict.m133.activities.guestbook.web.handlers;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import ch.epai.ict.m133.activities.guestbook.domain.MessageRepository;
import ch.epai.ict.m133.activities.guestbook.web.utils.ContextUtils;
import ch.epai.ict.m133.activities.guestbook.web.utils.LoginPageErrorUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Gestionnaire de requête pour la méthode GET sur la ressource guestbook.
 *
 */
public final class GuestbookPageHandler implements Handler {

    private final MessageRepository messageRepo;
    private final String newMessageActionUrl;

    /**
     * Constructeur.
     * 
     * @param messageRepo un dépôt de message
     * @param newMessageActionUrl l'url d'action pour l'ajout d'un message
     */
    public GuestbookPageHandler(MessageRepository messageRepo, String newMessageActionUrl) {
        this.messageRepo = messageRepo;
        this.newMessageActionUrl = newMessageActionUrl;
    }

    /**
     * Effectue le traitement des requêtes.
     *
     * @param ctx le contexte de la requête
     */
    @Override
    public void handle(Context ctx) {

        Map<String, Object> data = new HashMap<>();
        data.put("title", "Guestbook");
        data.put("messages", this.messageRepo.getAllMessages());
        data.put("newMessageActionUrl", this.newMessageActionUrl);
        data.put("isAuthenticated", ContextUtils.isAuthenticated(ctx));
        data.put("error", LoginPageErrorUtils.getAndClearNewMessageError(ctx));
        data.put("dateFormatter", DateTimeFormatter.ofPattern("dd.MM.yyyy"));
        data.put("timeFormatter", DateTimeFormatter.ofPattern("hh:mm"));

        ctx.render("/guestbook.ftl", data);
    }
}
