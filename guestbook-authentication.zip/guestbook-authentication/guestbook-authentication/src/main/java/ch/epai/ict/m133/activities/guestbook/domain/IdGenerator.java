package ch.epai.ict.m133.activities.guestbook.domain;

import java.util.HashMap;
import java.util.Map;

/**
 * Représente une générateur d'identifiant unique.
 *
 * Permet de générer des identifiant unique pour différentes classes sans
 * dépendre des fonctionnalités de la base de données utilisée pour le stockage.
 */
public abstract class IdGenerator {

    private static Map<Class<?>, IdGenerator> generators = new HashMap<Class<?>, IdGenerator>();

    /**
     * Associe un générateur à une classe.
     *
     * @param entityClass une classe
     * @param generator un objet de type IdGenerator
     */
    public static void register(Class<?> entityClass, IdGenerator generator) {
        generators.put(entityClass, generator);
    }

    /**
     * Récuère le générateur correspondant à la classe.
     *
     * @param entityClass une classe
     * @return un générateur ou null
     */
    public static IdGenerator get(Class<?> entityClass) {
        return generators.get(entityClass);
    }

    /**
     * Renvoie le prochain identifiant.
     *
     * @return un identifiant
     */
    public abstract int getNextId();
}
