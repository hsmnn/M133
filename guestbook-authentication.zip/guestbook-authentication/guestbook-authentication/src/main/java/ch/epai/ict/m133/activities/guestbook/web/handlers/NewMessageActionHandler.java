package ch.epai.ict.m133.activities.guestbook.web.handlers;

import java.time.LocalDateTime;

import ch.epai.ict.m133.activities.guestbook.domain.Message;
import ch.epai.ict.m133.activities.guestbook.domain.MessageBuilder;
import ch.epai.ict.m133.activities.guestbook.domain.MessageRepository;
import ch.epai.ict.m133.activities.guestbook.web.utils.ContextUtils;
import ch.epai.ict.m133.activities.guestbook.web.utils.LoginPageErrorUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Gestionnaire de requête pour la méthode POST sur la ressource guestbook.
 *
 */
public final class NewMessageActionHandler implements Handler {

    private final MessageRepository messageRepo;
    private final String redirectUrl;

    /**
     * Constructeur
     *
     * @param messageRepo un dépôt de messages
     * @param redirectUrl une url de redirection (POST/REDIRECT/GET)
     */
    public NewMessageActionHandler(MessageRepository messageRepo, String redirectUrl) {
        this.messageRepo = messageRepo;
        this.redirectUrl = redirectUrl;
    }

    /**
     * Effectue le traitement des requêtes.
     *
     * @param ctx le contexte de la requête
     */
    @Override
    public void handle(Context ctx) {

        // L'opération est interdite si l'utilisateur ne s'est pas authentifié.
        if (!ContextUtils.isAuthenticated(ctx)) {
            ctx.status(403);
            return;
        }

        // Récupère les données du formulaire
        String messageBody = ctx.formParam("message");

        // Vérifie que les données sont valide. Si ce n'est pas le cas, stocke une
        // erreur dans la session et répond avec une demande de redirection vers
        // le formulaire.
        if (messageBody.isEmpty()) {
            LoginPageErrorUtils.setSignUpError(ctx, LoginPageErrorUtils.REQUIRED_FIELDS_MISSING);
            ctx.redirect("/guestbook");
            return;
        }

        // Utilise un builder pour construire un nouveau message et ajoute ce nouveau
        // message dans le dépôt.
        Message message = MessageBuilder.create()
            .setDate(LocalDateTime.now())
            .setAuthor(ContextUtils.getUserDisplayName(ctx))
            .setBody(messageBody)
            .buildMessage();
        this.messageRepo.addMessage(message);

        // Répond par une demande de redirection vers la ressource guestbook.
        ctx.redirect(this.redirectUrl);
    }
}
