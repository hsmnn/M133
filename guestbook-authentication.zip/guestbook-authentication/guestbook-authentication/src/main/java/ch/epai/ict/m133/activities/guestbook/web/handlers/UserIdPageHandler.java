package ch.epai.ict.m133.activities.guestbook.web.handlers;

import java.util.HashMap;
import java.util.Map;

import ch.epai.ict.m133.activities.guestbook.domain.User;
import ch.epai.ict.m133.activities.guestbook.domain.UserDirectory;
import ch.epai.ict.m133.activities.guestbook.web.utils.ContextUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

public class UserIdPageHandler implements Handler {

    private final UserDirectory userDir;

    public UserIdPageHandler(UserDirectory userDir){
        this.userDir = userDir;
    }

    @Override
    public void handle(Context ctx) {

        int userId = Integer.parseInt(ctx.pathParam("userid"));
        User user = this.userDir.getUserById(userId);
        Map<String, Object> data = new HashMap<>();
        data.put("title", "User");
        data.put("name", "world");
        data.put("isAuthenticated", false);
        data.put("userId", userId);
        data.put("userName", user.getUserName());
        data.put("userEmail", user.getEmail());
        data.put("userDisplayName", user.getDisplayName());
        data.put("userRole", user.getRole());
        data.put("isAdmin", ContextUtils.isAdmin(ctx));


        ctx.render("/userid.ftl", data);
    }

}
