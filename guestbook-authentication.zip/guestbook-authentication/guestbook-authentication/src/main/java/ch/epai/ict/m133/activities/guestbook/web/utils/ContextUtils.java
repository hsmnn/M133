package ch.epai.ict.m133.activities.guestbook.web.utils;

import ch.epai.ict.m133.activities.guestbook.domain.User;
import io.javalin.http.Context;

/**
 * Classe utilitaire pour étendre les fonctionnalités de la classe Context de
 * Javalin.
 *
 * Les méthodes utilisent les attributs du contexte. Contrairement au attributs
 * de session (sessionAttribute), ces attributs sont transitoires et sont donc
 * perdus lorsque le traitement de la requête est terminé.
 */
public final class ContextUtils {

    private static final String AUTHENTICATED_USER_ATTRIBUTE = "USER_PRINCIPAL";

    /**
     * Détermine si la requête est authentifiée.
     *
     * @param ctx le contexte
     * @return vrai si et seulement si la requête est déjà authentifiée
     */
    public static boolean isAuthenticated(Context ctx) {
        return getUser(ctx) != null;
    }

    public static boolean isAdmin(Context ctx) {
        if ((getUser(ctx) != null) && (getUser(ctx).getRole().equals("admin"))) {
            return true;
        } 
        return false;
    }

    /**
     * Renvoie l'utilisateur authentifié associée à la requête.
     *
     * @param ctx le contexte
     * @return un utilisateur
     */
    public static User getUser(Context ctx) {
        return (User) ctx.attribute(AUTHENTICATED_USER_ATTRIBUTE);
    }

    /**
     * Renvoie le nom affichable de l'utilisateur authentifié.
     *
     * @param ctx le contexte
     * @return le nom de l'utilisateur
     */
    public static String getUserDisplayName(Context ctx) {
        User user = getUser(ctx);
        if (user != null) {
            return user.getDisplayName();
        }
        return "";
    }

    /**
     * Associe l'utilisateur authentifié dans la requête.
     *
     * @param ctx  le contexte
     * @param user l'utilisateur authentifié
     */
    public static void setUser(Context ctx, User user) {
        ctx.attribute(AUTHENTICATED_USER_ATTRIBUTE, user);
    }
}
