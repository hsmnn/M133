package ch.epai.ict.m133.activities.guestbook.domain;

import java.time.LocalDateTime;

/**
 * Represente un message dans le guestbook.
 *
 */
public final class Message {
    private final int id;
    private final LocalDateTime date;
    private final String author;
    private final String body;

    /**
     * Constructor.
     *
     * @param id l'identifiant du message
     * @param date la date de publication du message
     * @param author le nom ou le pseudo de l'auteur
     * @param body le corps du message
     */
    public Message(int id, LocalDateTime date, String author, String body) {
        this.id = id;
        this.date = date;
        this.author = author;
        this.body = body;
    }

    /**
     * Renvoie l'identifiant du message.
     *
     * @return un identifiant
     */
    public int getId() {
        return this.id;
    }

    /**
     * Renvoie la date et l'heure de publication.
     *
     * @return une date
     */
    public LocalDateTime getDate() {
        return this.date;
    }

    /**
     * Renvoie le nom ou le pseudo de l'auteur.
     *
     * @return le nom ou le pseudo de l'auteur
     */
    public String getAuthor() {
        return this.author;
    }

    /**
     * Renvoie le corps du message.
     *
     * @return le corps du message
     */
    public String getBody() {
        return this.body;
    }
}
