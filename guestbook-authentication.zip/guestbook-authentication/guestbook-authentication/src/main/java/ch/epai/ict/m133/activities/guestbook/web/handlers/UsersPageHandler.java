package ch.epai.ict.m133.activities.guestbook.web.handlers;

import java.util.HashMap;
import java.util.Map;

import ch.epai.ict.m133.activities.guestbook.domain.UserDirectory;
import ch.epai.ict.m133.activities.guestbook.web.utils.ContextUtils;
import ch.epai.ict.m133.activities.guestbook.web.utils.LoginPageErrorUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

public class UsersPageHandler implements Handler {

    private final UserDirectory userDir;

    public UsersPageHandler(UserDirectory userDir){
        this.userDir = userDir;
    }

    @Override
    public void handle(Context ctx) {
        
        Map<String, Object> data = new HashMap<>();
        data.put("title", "Users");
        data.put("users", this.userDir.getAllUsers());
        data.put("isAuthenticated", ContextUtils.isAuthenticated(ctx));
        data.put("isAdmin", ContextUtils.isAdmin(ctx));
        data.put("error", LoginPageErrorUtils.getAndClearNewMessageError(ctx));

        ctx.render("/users.ftl", data);
    }
}
