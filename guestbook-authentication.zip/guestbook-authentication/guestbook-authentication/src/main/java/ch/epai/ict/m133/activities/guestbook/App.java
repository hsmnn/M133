package ch.epai.ict.m133.activities.guestbook;

/**
 * Représente l'application.
 */
public class App {

    /**
     * Point d'entrée du programme.
     *
     * @param args paramètres de la ligne de commande
     */
    public static void main(String[] args) {

        final AppConfig config = new AppConfig();

        // Construit et démarre un nouveau server HTTP.
        ServerBuilder.create(config)
                .build()
                .start(config.getServerPort());
    }
}
