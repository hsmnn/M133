package ch.epai.ict.m133.activities.guestbook.web.handlers;

import java.util.HashMap;
import java.util.Map;

import ch.epai.ict.m133.activities.guestbook.web.utils.LoginPageErrorUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Gestionnaire de requête pour la page login.
 */
public final class LoginPageHandler implements Handler {

    private final String signInActionUrl;

    /**
     * Constructeur.
     *
     * @param signInActionUrl URL d'action du formulaire de connexion
     */
    public LoginPageHandler(String signInActionUrl) {
        this.signInActionUrl = signInActionUrl;
    }

    /**
     * Effectue le traitement des requêtes.
     *
     * @param ctx le contexte de la requête
     */
    @Override
    public void handle(Context ctx) throws Exception {

        Map<String, Object> data = new HashMap<>();
        data.put("title", "Log in");
        data.put("name", "world");
        data.put("isAuthenticated", false);
        data.put("signInActionUrl", this.signInActionUrl);
        // Récupère les éventuelle erreurs depuis la session (voir le template).
        data.put("signInError", LoginPageErrorUtils.getAndClearSignInError(ctx));

        ctx.render("/login.ftl", data);
    }
}
