package ch.epai.ict.m133.activities.guestbook.domain;

import java.time.LocalDateTime;

/**
 * Permet de construre une instance de la classe User.
 */
public class MessageBuilder {

    private Integer id;
    private String author;
    private String body;
    private LocalDateTime date;

    /**
     * Renvoie un objet qui implémente ce type.
     *
     * @return un builder
     */
    public static MessageBuilder create() {
        return new MessageBuilder();
    }


    /**
     * Consstructeur.
     */
    private MessageBuilder() {

        // Par défaut les variables membres n'ont pas de valeur.
        this.id = null;
        this.author = null;
        this.body = null;
        this.date = null;
    }

    /**
     * Permet de définir l'identifiant.
     *
     * @param id l'identifiant
     */
    public MessageBuilder setId(int id) {
        this.id = id;
        return this;
    }

    /**
     * Permet de définir le nom ou le pseudo.
     *
     * @param author le nom ou le pseudo de l'auteur
     */
    public MessageBuilder setAuthor(String author) {
        this.author = "" + author;
        return this;
    }

    /**
     * Permet de définir le corps du message.
     *
     * @param body le corps du message
     */
    public MessageBuilder setBody(String body) {
        this.body = body;
        return this;
    }

    /**
     * Permet de définir la date de publication.
     *
     * @param date la date de publication
     */
    public MessageBuilder setDate(LocalDateTime date) {
        this.date = date;
        return this;
    }

    /**
     * Renvoie un nouvel objet de type Message. Si l'identifiant n'est pas définit,
     * un identifiant est généré automatiquement.
     *
     * @return un objet de type Message
     */
    public Message buildMessage() {

        Integer newId = this.id;
        LocalDateTime newDate = this.date;

        // Si l'identifiant n'a pas été définit, utilise le générateur d'identifiant.
        if (newId == null) {
            newId = IdGenerator.get(Message.class).getNextId();
        }
        // Si la date de publication n'a pas été définie, la date courante est utilisée.
        if (newDate == null) {
            newDate = LocalDateTime.now();
        }
        return new Message(newId, newDate, this.author, this.body);
    }
}
