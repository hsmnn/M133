USE guestbook_auth;

INSERT INTO message (message_id, user_name, message_body) VALUES (1, 'albert', 'message 1');
INSERT INTO message (message_id, user_name, message_body) VALUES (2, 'pierre', 'message 2');
INSERT INTO message (message_id, user_name, message_body) VALUES (3, 'ludwig', 'message 3');

-- Username : test1 / Password : epai123
INSERT INTO user (user_id, user_name, email, display_name, password_hash, role) VALUES (1, "test1", "test1@test.ch", "test1 teet1", "$2a$10$SkW31ed2BDYO1KhIICXnwOT2YANKkV5JzNwwKxkUptEvJFIht7iS6", "user");
-- Username : test2 / Password : epai321
INSERT INTO user (user_id, user_name, email, display_name, password_hash, role) VALUES (2, "test2", "test2@test.ch", "test2 teet2", "$2a$10$YAYEMOv6exO.BEpt.05W6O.EQdvCPLcE3Vya8RxhiioLZhQgPC4xq", "admin");
