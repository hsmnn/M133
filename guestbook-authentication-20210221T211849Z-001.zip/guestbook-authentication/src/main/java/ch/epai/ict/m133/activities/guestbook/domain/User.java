package ch.epai.ict.m133.activities.guestbook.domain;


/**
 * Représente un utilisateur du site.
 */
public final class User {
    private final int id;
    private final String userName;
    private final String email;
    private final String displayName;
    private final String role;

    /**
     * Constructeur.
     *
     * @param id un identifiant
     * @param userName un nom d'utilisateur (utilisé pour le login)
     * @param email une adressse de courriel
     * @param displayName un nom pouvant être affiché dans le site
     */
    public User(int id, String userName, String email, String displayName, String role) {
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.displayName = displayName;
        this.role = role;
    }

    /**
     * Renvoie l'identifiant de l'utilisateur.
     *
     * @return un identifiant
     */
    public int getId() {
        return this.id;
    }

    /**
     * Renvoie le nom utilisé pour la connection.
     *
     * @return un nom d'utilisateur
     */
    public String getUserName() {
        return this.userName;
    }

    /**
     * Renvoie l'adresse de courriel de l'utilisateur.
     *
     * @return une adresse de courriel
     */
    public String getEmail() {
        return this.email;
    }

    /**
     * Revoie le nom qui doit être affiché dans le site.
     *s
     * @return un nom d'utilisateur
     */
    public String getDisplayName() {
        return this.displayName;
    }

    public String getRole() {
        return this.role;
    }
}
