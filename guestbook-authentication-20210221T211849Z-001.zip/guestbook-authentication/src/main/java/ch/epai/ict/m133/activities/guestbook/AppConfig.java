package ch.epai.ict.m133.activities.guestbook;

public class AppConfig {

    private static final int DEFAULT_PORT = 8080;
    private static final String TEMPLATE_PATH = "/templates";
    private static final String DB_URL = "jdbc:mariadb://localhost/guestbook_auth";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "epai123";

    public String getTemplatePath() {
        return TEMPLATE_PATH;
    }

    public String getDbUrl() {
        return DB_URL;
    }

    public String getDbPassword() {
        return DB_PASSWORD;
    }

    public String getDbUser() {
        return DB_USER;
    }

    public int getServerPort() {
        return DEFAULT_PORT;
    }
}
