package ch.epai.ict.m133.activities.guestbook.domain;

/**
 * Permet de construre une instance de la classe User.
 */
public class UserBuilder {

    private Integer id;
    private String userName;
    private String email;
    private String displayName;
    private String role;

    /**
     * Renvoie un objet qui implémente ce type.
     *
     * @return un builder
     */
    public static UserBuilder create() {
        return new UserBuilder();
    }

    /**
     * Constructeur.
     */
    private UserBuilder() {

        // Par défaut les variables membres n'ont pas de valeur.
        this.id = null;
        this.userName = null;
        this.email = null;
        this.displayName = null;
        this.role = null;
    }


    /**
     * Permet de définir l'identifiant.
     *
     * @param id l'identifiant
     */
    public UserBuilder setId(int id) {
        this.id = id;
        return this;
    }

    /**
     * Permet de définir le nom de l'utilisateur.
     *
     * @param userName le nom de l'utilisateur
     */
    public UserBuilder setUserName(String userName) {
        this.userName = userName;
        return this;
    }

    /**
     * Permet de définir l'adresse de courriel.
     *
     * @param email une adresse de courriel
     */
    public UserBuilder setEmail(String email) {
        this.email = email;
        return this;
    }

    /**
     * Permet de définir un nom affichable.
     *
     * @param displayName un nom affichable
     */
    public UserBuilder setDisplayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    public UserBuilder setRole(String role) {
        this.role = role;
        return this;
    }

    /**
     * Renvoie un nouvel objet de type User. Si l'identifiant n'est pas définit, un
     * identifiant est généré automatiquement.
     *
     * @return un objet de type User
     */
    public User buildUser() {

        Integer newId = this.id;

        // Si l'identifiant n'a pas été définit, utilise le générateur d'identifiant.
        if (newId == null) {
            newId = IdGenerator.get(User.class).getNextId();
        }
        return new User(newId, this.userName, this.email, this.displayName, this.role);
    }
}
