package ch.epai.ict.m133.activities.guestbook.web.handlers;

import java.util.HashMap;
import java.util.Map;

import ch.epai.ict.m133.activities.guestbook.web.utils.LoginPageErrorUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Gestionnaire de requête pour la page login.
 */
public final class SignupPageHandler implements Handler {

    private final String signUpActionUrl;

    /**
     * Constructeur.
     *
     * @param signUpActionUrl URL d'action du formulaire d'inscription
     */
    public SignupPageHandler(String signUpActionUrl) {
        this.signUpActionUrl = signUpActionUrl;
    }

    /**
     * Effectue le traitement des requêtes.
     *
     * @param ctx le contexte de la requête
     */
    @Override
    public void handle(Context ctx) throws Exception {

        Map<String, Object> data = new HashMap<>();
        data.put("title", "Sign up");
        data.put("name", "world");
        data.put("isAuthenticated", false);
        data.put("signUpActionUrl", this.signUpActionUrl);

        // Récupère les éventuelle erreurs depuis la session (voir le template).
        data.put("signUpError", LoginPageErrorUtils.getAndClearSignUpError(ctx));

        ctx.render("/signup.ftl", data);
    }
}
