package ch.epai.ict.m133.activities.guestbook.data.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ch.epai.ict.m133.activities.guestbook.domain.Message;
import ch.epai.ict.m133.activities.guestbook.domain.MessageBuilder;
import ch.epai.ict.m133.activities.guestbook.domain.MessageRepository;

/**
 * Implémente un dépôt de messages avec une base de données SQL.
 */
public final class SqlMessageDataMapper extends MessageRepository {

    private SqlConnectionManager connectionManager;

    /**
     * Constructeur.
     *
     * @param connectionManager un gestionnaire de connection sql
     */
    public SqlMessageDataMapper(SqlConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public List<Message> getAllMessages() {
        List<Message> messages = new ArrayList<>();

        String query = "SELECT * FROM message";

        try (Connection connection = this.connectionManager.getConnection();
                Statement statement = connection.createStatement();) {

            ResultSet rs = statement.executeQuery(query);

            while (rs.next()) {
                Timestamp date = rs.getTimestamp("message_date");

                Message message = MessageBuilder.create()
                    .setId(rs.getInt("message_id"))
                    .setDate(date.toLocalDateTime())
                    .setAuthor(rs.getString("user_name"))
                    .setBody(rs.getString("message_body"))
                    .buildMessage();

                messages.add(message);
            }

        } catch (Exception ex) {
            throw new RuntimeException("Can't get message list.", ex);
        }
        // renvoie une liste non mofiable
        return Collections.unmodifiableList(messages);
    }

    /**
     * Ajoute un nouveau message dans la base de données.
     *
     * @param message le message
     */
    @Override
    public void addMessage(Message message) {

        String queryTemplate = "INSERT INTO message (message_id, message_date, user_name, message_body) VALUES(?, ?, ?, ?);";

        try (

                Connection connection = this.connectionManager.getConnection();
                PreparedStatement statement = connection.prepareStatement(queryTemplate);) {

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            Timestamp timestamp = Timestamp.valueOf(message.getDate().format(formatter));

            statement.setInt(1, message.getId());
            statement.setTimestamp(2, timestamp);
            statement.setString(3, message.getAuthor());
            statement.setString(4, message.getBody());
            statement.executeUpdate();

        } catch (Exception ex) {
            throw new RuntimeException("Can't add new message.", ex);
        }
    }

}
