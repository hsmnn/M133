package ch.epai.ict.m133.activities.guestbook.domain;

import java.util.List;


/**
 * Représente le dépôt de messages.
 */
public abstract class MessageRepository {

    /**
     * Revoie une liste non modifiable de tous les messages.
     *
     * @return une liste de messages
     */
    public abstract List<Message> getAllMessages();

    /**
     * Ajoute un message dans le répertoire.
     *
     * @param message un message
     */
    public abstract void addMessage(Message message);
}
