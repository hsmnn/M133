package ch.epai.ict.m133.activities.guestbook.web.utils;

import io.javalin.http.Context;

/**
 * Classe utilitaire permettant de simplifier la gestion des erreurs dans les
 * formulaires.
 */
public final class LoginPageErrorUtils {

    public static final int REQUIRED_FIELDS_MISSING = 1;
    public static final int PASSWORD_MISMATCH = 2;
    public static final int INVALID_CREDENTIALS = 3;
    public static final int USERNAME_ALREADY_EXISTS = 4;
    public static final int EMAIL_ALREADY_EXISTS = 5;
    public static final int USER_SUCCESSFULLY_CREATED = 6;

    private static final String SIGN_IN_ERROR_ATTRIBUTE = "SIGN_IN_ERROR";
    private static final String SIGN_UP_ERROR_ATTRIBUTE = "SIGN_UP_ERROR";
    private static final String NEW_MESSAGE_ERROR_ATTRIBUTE = "NEW_MESSAGE_ERROR";

    public static int getAndClearSignUpError(Context ctx) {
        return SessionUtils.getAndClearAttribute(ctx, SIGN_UP_ERROR_ATTRIBUTE, 0);
    }

    public static void setSignUpError(Context ctx, int error) {
        SessionUtils.setAttribute(ctx, SIGN_UP_ERROR_ATTRIBUTE, error);
    }

    public static int getAndClearSignInError(Context ctx) {
        return SessionUtils.getAndClearAttribute(ctx, SIGN_IN_ERROR_ATTRIBUTE, 0);
    }

    public static void setSignInError(Context ctx, int error) {
        SessionUtils.setAttribute(ctx, SIGN_IN_ERROR_ATTRIBUTE, error);
    }

    public static int getAndClearNewMessageError(Context ctx) {
        return SessionUtils.getAndClearAttribute(ctx, NEW_MESSAGE_ERROR_ATTRIBUTE, 0);
    }

    public static void setNewMessageError(Context ctx, int error) {
        SessionUtils.setAttribute(ctx, NEW_MESSAGE_ERROR_ATTRIBUTE, error);
    }
}
