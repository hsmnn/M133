package ch.epai.ict.m133.activities.guestbook.web.handlers;

import ch.epai.ict.m133.activities.guestbook.domain.User;
import ch.epai.ict.m133.activities.guestbook.domain.UserBuilder;
import ch.epai.ict.m133.activities.guestbook.domain.UserDirectory;
import ch.epai.ict.m133.activities.guestbook.web.utils.LoginPageErrorUtils;
import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Gestionnaire de requête pour la méthode POST sur la ressource signup.
 *
 */
public final class UserIdActionHandler implements Handler {

    private final UserDirectory userDir;

    /**
     * Constructeur
     *
     * @param signUpFormUrl URL du formulaire d'inscription
     */
    public UserIdActionHandler(UserDirectory userDir) {
        this.userDir = userDir;
    }

    /**
     * Effectue le traitement des requêtes.
     *
     * @param ctx le contexte de la requête
     */
    @Override
    public void handle(Context ctx) {

        int userId = Integer.parseInt(ctx.pathParam("userid"));
        User user = this.userDir.getUserById(userId);
        this.userDir.deleteUser(user);
        ctx.redirect("/users");
    }
}