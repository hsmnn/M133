package ch.epai.ict.m133.activities.guestbook.domain;

import java.util.List;

/**
 * Représente le répertoire des utilisateurs.
 */
public abstract class UserDirectory {

    /**
     * Revoie une liste non modifiable de tous les utilisateurs.
     *
     * @return une liste d'utilisateurs
     */
    public abstract List<User> getAllUsers();

    /**
     * Renvoie l'utilisateur qui correspond à l'id passé en paramètre.
     *
     * @param id un identifiant
     * @return un utilisateur ou null
     */
    public abstract User getUserById(int id);

    /**
     * Renvoie l'utilisateur correspondant à l'adresse de courriel passée en
     * paramètre.
     *
     * @param email une adresse de courriel (insensible à la casse)
     * @return un utilisateur ou null
     */
    public abstract User getUserByEmail(String email);

    /**
     * Renvoie l'utilisateur correspondant au nom d'utilisateur passé en paramètre.
     *
     * @param userName un nom d'utilisateur (insensible à la casse)
     * @return un utilisateur ou null
     */
    public abstract User getUserByUserName(String userName);

    /**
     * Ajoute un utilisateur dans le répertoire.
     *
     * @param user     un utilisateur
     * @param password un mot de passe
     */
    public abstract void addUser(User user, String password);

    /**
     * Renvoie vrai si le mot de passe correspond au mot de passe de l'utilisateur
     * dont le nom est passé en paramètre.
     *
     * @param userName un nom d'utilisateur (insensible à la casse)
     * @param password un mot de passe
     *
     * @return vrai si et seulement si le mot de passe correspond exactement au mot
     *         de passe de l'utilisateur.
     */
    public abstract boolean validate(String userName, String password);

    public abstract void deleteUser(User user);

}
