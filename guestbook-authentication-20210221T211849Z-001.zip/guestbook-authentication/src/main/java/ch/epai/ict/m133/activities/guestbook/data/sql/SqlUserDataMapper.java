package ch.epai.ict.m133.activities.guestbook.data.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.mindrot.jbcrypt.BCrypt;

import ch.epai.ict.m133.activities.guestbook.domain.User;
import ch.epai.ict.m133.activities.guestbook.domain.UserBuilder;
import ch.epai.ict.m133.activities.guestbook.domain.UserDirectory;


/**
 * Implémente un répertoire d'utilisateur.
 */
public final class SqlUserDataMapper extends UserDirectory {

    private SqlConnectionManager connectionManager;

    public SqlUserDataMapper(SqlConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM user;";
        try (
                Connection connection = this.connectionManager.getConnection();
                Statement statement = connection.createStatement();) {

            ResultSet rs = statement.executeQuery(query);
            while (rs.next()) {
                User user = UserBuilder.create()
                    .setId(rs.getInt("user_id"))
                    .setUserName(rs.getString("user_name"))
                    .setEmail(rs.getString("email"))
                    .setDisplayName(rs.getString("display_name"))
                    .setRole("role")
                    .buildUser();

                users.add(user);
            }
        } catch (Exception ex) {
            throw new RuntimeException("Can't get users list.", ex);
        }
        // renvoie une liste non mofiable
        return Collections.unmodifiableList(users);
    }

    @Override
    public User getUserById(int id) {
        User user = null;
        String queryTemplate = "SELECT * FROM user WHERE user_id = ?;";
        try (
                Connection connection = this.connectionManager.getConnection();
                PreparedStatement statement = connection.prepareStatement(queryTemplate); ) {

            statement.setInt(1, id);
            user = this.getUserFromResultSet(statement.executeQuery());
        } catch (Exception ex) {
            throw new RuntimeException("Can't get user.", ex);
        }
        return user;
    }

    @Override
    public User getUserByEmail(String email) {
        User user = null;
        String queryTemplate = "SELECT * FROM user WHERE email = ?;";
        try (
                Connection connection = this.connectionManager.getConnection();
                PreparedStatement statement = connection.prepareStatement(queryTemplate); ) {

            statement.setString(1, email);
            user = this.getUserFromResultSet(statement.executeQuery());
        } catch (Exception ex) {
            throw new RuntimeException("Can't get user.", ex);
        }
        return user;
    }

    @Override
    public User getUserByUserName(String userName) {
        User user = null;
        String queryTemplate = "SELECT * FROM user WHERE user_name = ?;";

        try (
                Connection connection = this.connectionManager.getConnection();
                PreparedStatement statement = connection.prepareStatement(queryTemplate); ) {

            statement.setString(1, userName);
            user = this.getUserFromResultSet(statement.executeQuery());

        } catch (Exception ex) {
            throw new RuntimeException("Can't get user.", ex);
        }

        return user;
    }

    @Override
    public boolean validate(String userName, String password) {

        String passwordHash = "";
        String queryTemplate = "SELECT password_hash FROM user WHERE user_name = ?;";

        try (
                Connection connection = this.connectionManager.getConnection();
                PreparedStatement statement = connection.prepareStatement(queryTemplate); ) {

            statement.setString(1, userName);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                passwordHash = rs.getString("password_hash");
            }

        } catch (Exception ex) {
            throw new RuntimeException("Can't get user.", ex);
        }

        if (passwordHash.isEmpty()) {
            return false;
        }

        return BCrypt.checkpw(password, passwordHash);
    }


    @Override
    public void addUser(User user, String password) {
        String queryTemplate =
                "INSERT INTO user (user_id, user_name, email, display_name, password_hash, role) VALUES (?, ?, ?, ?, ?, ?);";

        try (
                Connection connection = this.connectionManager.getConnection();
                PreparedStatement statement = connection.prepareStatement(queryTemplate); ) {

            String passwordHash = BCrypt.hashpw(password, BCrypt.gensalt());

            statement.setInt(1, user.getId());
            statement.setString(2, user.getUserName());
            statement.setString(3, user.getEmail());
            statement.setString(4, user.getDisplayName());
            statement.setString(5, passwordHash);
            statement.setString(6, user.getRole());
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                passwordHash = rs.getString("user_name");
            }

        } catch (Exception ex) {
            throw new RuntimeException("Can't get user.", ex);
        }
    }

    @Override
    public void deleteUser(User user) {
        String queryTemplate = "DELETE FROM user WHERE user_id = ?";

        try (
            Connection connection = this.connectionManager.getConnection();
            PreparedStatement statement = connection.prepareStatement(queryTemplate);) {

                statement.setInt(1, user.getId());
                ResultSet rs = statement.executeQuery();
                
            } catch (Exception ex) {
                throw new RuntimeException("Can't delete user.", ex);
            }
    }

    private User getUserFromResultSet(ResultSet rs) throws SQLException {
        User user = null;

        while (rs.next()) {
            user = UserBuilder.create()
                .setId(rs.getInt("user_id"))
                .setUserName(rs.getString("user_name"))
                .setEmail(rs.getString("email"))
                .setDisplayName(rs.getString("display_name"))
                .setRole(rs.getString("role"))
                .buildUser();
        }

        return user;
    }
}
