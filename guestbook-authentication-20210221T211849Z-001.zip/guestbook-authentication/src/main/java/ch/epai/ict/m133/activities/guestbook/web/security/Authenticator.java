package ch.epai.ict.m133.activities.guestbook.web.security;

import io.javalin.Javalin;
import io.javalin.http.Context;

/**
 * Représente un mécanisme d'authentification.
 */
public abstract class Authenticator {

    private static Authenticator authenticator;

    /**
     * Constructeur.
     *
     * @param app l'application Javalin
     */
    protected Authenticator(Javalin app) {

        // Attache un gestionnaire qui est appelé pour chaque requête dont le rôle est
        // d'authentifier la requête si elle contient des données de connexion.
        app.before(this::doAuthenticate);
    }

    /**
     * Ajoute un mécanisme d'authentification
     *
     * @param authenticator un mécanisme d'authentification
     */
    public static void register(Authenticator authenticator) {
        Authenticator.authenticator = authenticator;
    }

    /**
     * Démarre le processus d'autentification de l'utilisateur si la requête n'est
     * pas déjà authentifiée. L'appelle de cette méthode initie généralement
     * une interaction avec l'utilisateur (p. ex. avec un formulaire).
     *
     * @param ctx le contexte
     */
    public static void login(Context ctx) {
        authenticator.doLogin(ctx);
    }

    /**
     * Démarre le processus d'autentification de l'utilisateur si la requête n'est
     * pas déjà authentifiée. L'appelle de cette méthode initie généralement
     * une interaction avec l'utilisateur (p. ex. avec un formulaire).
     *
     * @param ctx le contexte
     */
    protected abstract void doLogin(Context ctx);

    /**
     * Utilise les données de connexion qui se trouvent dans la requête, s'il y en
     * a, pour connecter l'utilisateur correspondant. S'il n'y a pas de données de
     * connexion, la méthode se termine immédiatement et sans erreur. Cette méthode
     * ne doit pas initier d'interaction avec l'utilisateur.
     *
     * @param ctx le contexte
     */
    protected abstract void doAuthenticate(Context ctx);
}
